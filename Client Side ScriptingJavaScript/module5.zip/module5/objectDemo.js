var Computer = {
    Make : "HP",
    model  : "15-bs013dx",
    cpu     : "Intel Core i3",
    cpu_frequency  : "2.4 GHz",
    Memory : "8 GB",
    color : "Black",
  };


computer.GPUmake_model = "HP Pavillion";
Computer.disk_space = "1000GB";

var x = computer;
x.cpu_frequency = "2.5 GHz";

Computer[memory] = "914 GB";

delete computer.color; 

for (computer [key, value] of Object.entries(computer)) {
  console.log(key, value);
}

  /*Initializes a new Object representing a personal computer.  When you initialize the Object, give it the following properties, and assign whichever values you would like
make (of the pc or motherboard)
model (of the pc or motherboard)
cpu
cpu frequency (in Gigahertz)
memory (in Gigabytes)
color
On separate lines of code, add two new fields:
GPU make/model (e.g., "nVidia GeForce GTX 1080")
disk space (in Gigabytes)
On two more lines, modify the CPU frequency and memory, one using dot notation to access the property, another using bracket notation to access the property
On the next line, delete the color property
Lastly, loop through the object and print each key/value pair
(hint: use 'console.log(  )' as a print function.
This script can be tested by uploading to thompson, then running the command:
node  objectDemo.js
Alternatively, you may go to http://repl.it and create a Node.js REPL (interactive prompt and code editor) where you can copy, paste and test your code
Alternatively, you may install Node.js on your personal computer and integrate it with VS Code*/