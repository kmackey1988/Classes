<div class="navbar">
			<div class="logo_div">
				<a href="index.php"><h1>Lets Talk About Books</h1></a>
			</div>
			<ul>
			  <li><a class="active" href="index.php">Home</a></li>
			  <li><a href="news.php">News</a></li>
			  <li><a href="contact.php">Contact</a></li>
			  <li><a href="about.php">About</a></li>
			</ul>
		</div>