<p>
					Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Nulla ac elit ut
					erat tempor vehicula. Duis enim eros, gravida eu, pretium ut, dapibus et, enim.
					Sed ac tellus.
					<img src="1.jpg" alt="" class="float-right" width="100" height="75"/>
					Nulla vel arcu. Proin ac sapien et neque pellentesque mollis.
					Praesent ut magna sed tortor luctus pretium. Proin a est gravida dui
					pellentesque tincidunt. Nunc at ipsum. Suspendisse elit. Fusce sit amet lectus.
					Quisque et neque vitae odio sagittis
					tincidunt.
				</p>
				<p>
					Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Nulla ac elit ut
					erat tempor vehicula. Duis enim eros, gravida eu, pretium ut, dapibus et, enim.
					Sed ac tellus. Nulla vel arcu. Proin ac sapien et neque pellentesque mollis.
					Praesent ut magna sed tortor luctus pretium. Proin a est gravida dui
					pellentesque tincidunt. Nunc at ipsum. Suspendisse elit. Fusce sit amet lectus.
					Quisque et neque vitae odio sagittis
					tincidunt.
				</p> 