<div id="footer">
			<hr />
			Copyright your name, Design by Bryan Lass, <a href="http://www.idavista.com">IdaVista</a>, Inc.
			<br />Download your free auto maintenance reminder at <a href="http://www.idavista.com/transroster">www.idavista.com</a>

</div>