<div class="block">
    <!-- start fblock -->
    <?php
		include("fblock.php");
	?>
	<!-- end fblock -->    
 
</div>
<div class="block">
    <!-- start sblock -->
    <?php
		include("sblock.php");
	?>
	<!-- end sblock -->    
	

</div>