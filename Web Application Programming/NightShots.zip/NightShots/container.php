<div id="container">

		<!-- start header -->
		<?php
			include("header.php");
		?>
		<!-- start header -->

		<div id="leftCol">

			<!-- start menu -->
			<?php
				include("menu.php");
			?>
			

			<!-- start menu -->	

			<!-- start news -->	

			<?php
				include("news.php");
			?>
			<!-- start news -->	

		</div>