<div id="header">
			<div id="search">
				<input type="text" id="searchText" />
				<span style="background-color:black;color:#FFF;padding:2px;border:#FCE796 solid 1px;">Search</span>
			</div>
			<h1>Night Shots</h1>
</div>