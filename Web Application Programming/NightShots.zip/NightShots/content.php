<div id="content">

			<h3>Hello!</h3>
			<p class="top">
				Here is a template that I hope you will all enjoy. All images were taken by me and you are free to use them on your own site if you wish.
				<br />
				This template is free to use for both commercial or personal use provided that you give credit where credit is due by leaving the design credit in the footer.
				If you feel particularly generous you can link to <a href="http://www.findmytwinonline.com">http://www.findmytwinonline.com</a> or <a href="http://www.snappyad.com">http://www.snappyad.com</a>.
			</p>
			    <!-- start magnify -->
	        <?php
		        include("magnify.php");
	        ?>
	            <!-- end magnify container -->

            <!-- start block-->
	        <?php
		        include("block.php");
	        ?>
	        <!-- end block-->    

			
</div>