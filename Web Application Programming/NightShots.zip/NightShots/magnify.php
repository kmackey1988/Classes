<ul class="magnify">
				<li>
				<a href="#"><img src="1.jpg" alt="description" /><img src="1.jpg" alt="description" class="preview" /></a>
				</li>
				<li>
				<a href="#"><img src="2.jpg" alt="description" /><img src="2.jpg" alt="description" class="preview" /></a>
				</li>
				<li>
				<a href="#"><img src="3.jpg" alt="description" /><img src="3.jpg" alt="description" class="preview" /></a>
				</li>
				<li>
				<a href="#"><img src="4.jpg" alt="description" /><img src="4.jpg" alt="description" class="preview" /></a>
				</li>
			</ul>