<div id="menu">
				<ul>
					<li><a href="#">Home</a></li>
					<li><a href="#">Products</a></li>
					<li><a href="#">Services</a></li>
					<li><a href="#">Support</a></li>
					<li><a href="#">Order</a></li>
					<li><a href="#">News</a></li>
					<li><a href="#">About</a></li>

				</ul>
</div>