<div class="news">
				<h3>News:</h3>
				<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Nulla ac elit ut
					erat tempor vehicula. Duis enim eros, gravida eu, pretium ut, dapibus et, enim.
					Sed ac tellus.
				</p>
				<p>Want to have some fun try searching for you lookalike or doppelganger online at <a href="http://www.findmytwinonline.com">Find My Twin</a>.</p>
				<p>Get Free Classifieds at <a href="http://www.snappyad.com">SnappyAd</a>.</p>
				  <p>
				    <a href="http://validator.w3.org/check?uri=referer">Valid XHTML 1.0 Strict</a>
				  </p>

</div>